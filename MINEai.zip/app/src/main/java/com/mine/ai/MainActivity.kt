package com.mine.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mine.ai.ui.theme.AiTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("MINE_DATA", MODE_PRIVATE)

        setContent {
            AiTheme {
                MineApp(prefs)
            }
        }
    }
}

@Composable
fun MineApp(prefs: android.content.SharedPreferences) {

    // Load saved screen/progression
    var currentScreen by remember {
        mutableStateOf(
            prefs.getString("current_screen", "lobby") ?: "lobby"
        )
    }

    // Save whenever the screen changes
    LaunchedEffect(currentScreen) {
        prefs.edit()
            .putString("current_screen", currentScreen)
            .apply()
    }

    Scaffold(
        modifier = Modifier.fillMaxSize()
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
        ) {

            Text(
                text = "MINE",
                style = MaterialTheme.typography.headlineLarge
            )

            Spacer(modifier = Modifier.height(20.dp))

            when (currentScreen) {

                "lobby" -> {
                    Text("MINE Lobby")

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            currentScreen = "main"
                        }
                    ) {
                        Text("Enter MINE")
                    }
                }

                "main" -> {
                    Text("MINE is running")

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            currentScreen = "lobby"
                        }
                    ) {
                        Text("Back to Lobby")
                    }
                }
            }
        }
    }
}